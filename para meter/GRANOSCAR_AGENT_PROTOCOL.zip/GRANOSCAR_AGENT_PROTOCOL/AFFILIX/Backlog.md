# Backlog.md — AFFILIX (affilix.es)

## Pendientes activos
- Auditoria OWASP Top 10 sobre AFFILIX SHIELD
- Revisar rate-limits y manejo de errores por proveedor (Amazon, AliExpress, CJ, Hotmart, Printify)

## Completados (archivo historico — mover aqui lo que se cierre, no lo borres)
-
