# AGENT_TASKS.md — AFFILIX (affilix.es)

## Tarea actual de esta sesion
[PENDIENTE DE DEFINIR — completar al iniciar la proxima sesion con Codex/Claude Code]

Sugerencia segun el estado conocido del proyecto (ver PROJECT_STATE.md):
- Auditar AFFILIX SHIELD contra el checklist de OWASP Top 10 antes de cualquier nuevo despliegue a produccion.

## Archivos que debe tocar
-

## Archivos que debe producir
-
