# AGENT_TASKS.md — NEXFRAME FILMS

## Tarea actual de esta sesion
[PENDIENTE DE DEFINIR — completar al iniciar la proxima sesion con Codex/Claude Code]

Sugerencia segun el estado conocido del proyecto (ver PROJECT_STATE.md):
- Continuar la implementacion Codex modulo por modulo siguiendo el PDF maestro; confirmar con Jean Carlos cual modulo sigue antes de avanzar.

## Archivos que debe tocar
-

## Archivos que debe producir
-
