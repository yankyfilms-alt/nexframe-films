# AGENTS.md / CLAUDE.md — NEXFRAME FILMS

## Identidad del proyecto
- Nombre: NEXFRAME FILMS
- Stack: Next.js 14 + Supabase + Kling AI API (fork de Open Generative AI) + Stripe/PayPal
- Propietario: Jean Carlos (YANKYFILMS / MEDIAPLAYPROMO.COM)
- Maquina de desarrollo: GRANOSCAR (Windows 11, i7-13700K, RTX 4070 Ti 12GB, 96GB RAM)

## Comandos esenciales
- Instalar: npm install
- Desarrollo: npm run dev
- Build: npm run build
- Tests: npm run test
- Lint/Tipos: npm run lint && npm run typecheck
(Verificar contra package.json real del proyecto — estos son los comandos estandar de la mayoria de proyectos Next.js de Jean Carlos; ajustar si este proyecto usa otros scripts.)

## Reglas de arquitectura (lo que el codigo no deja ver a simple vista)
- Fork de Open Generative AI — revisar el codigo heredado antes de modificar la integracion con Kling AI
- Sistema multi-rol de administracion — revisar la capa de roles/permisos antes de tocar accesos
- 5 temas oscuros viven en su propia capa de design tokens — no hardcodear colores
- i18n activo — todo string de UI pasa por el sistema de internacionalizacion, no strings sueltos
- Integracion dual Stripe + PayPal — verificar ambos flujos de checkout antes de dar por cerrado el modulo de pagos

## Identidad visual (NO desviarse de esto)
- Paleta: negro profundo, rojo, ambar/dorado — estetica cinematografica oscura (5 temas, ver design tokens)
- Cero placeholders. Entregables siempre listos para produccion.

## Carpetas que NUNCA se deben tocar
- node_modules/, .next/, dist/, build/, vendor/, out/

## Antes de marcar una tarea como completa
1. Correr lint + typecheck + tests
2. Verificar que no hay placeholders ni TODOs sin resolver
3. Actualizar PROJECT_STATE.md con lo que se hizo

## Idioma
- Comunicacion siempre en espanol
- Comentarios de codigo en ingles (estandar de la industria)

## Compact Instructions
Cuando resumas esta conversacion:
- Conserva todos los cambios de API y su razon
- Conserva mensajes de error y sus soluciones
- Mantén la lista de archivos modificados
- Resume brevemente los intentos de exploracion que no funcionaron
