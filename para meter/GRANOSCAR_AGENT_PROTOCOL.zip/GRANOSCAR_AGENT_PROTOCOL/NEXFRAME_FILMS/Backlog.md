# Backlog.md — NEXFRAME FILMS

## Pendientes activos
- QA completo de los 5 temas oscuros
- Verificar checkout Stripe + PayPal en staging
- Documentar el sistema multi-rol en docs/roles.md

## Completados (archivo historico — mover aqui lo que se cierre, no lo borres)
-
