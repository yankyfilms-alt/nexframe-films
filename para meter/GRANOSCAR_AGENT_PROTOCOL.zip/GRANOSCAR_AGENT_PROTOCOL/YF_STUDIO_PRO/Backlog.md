# Backlog.md — YF Studio Pro

## Pendientes activos
- Implementar landing publica (si no esta hecho)
- Implementar dashboard de usuario (si no esta hecho)
- Implementar panel admin (si no esta hecho)

## Completados (archivo historico — mover aqui lo que se cierre, no lo borres)
-
