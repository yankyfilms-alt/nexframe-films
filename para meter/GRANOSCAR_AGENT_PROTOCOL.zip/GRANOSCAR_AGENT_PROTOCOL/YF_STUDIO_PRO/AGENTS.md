# AGENTS.md / CLAUDE.md — YF Studio Pro

## Identidad del proyecto
- Nombre: YF Studio Pro
- Stack: Ecosistema Google AI — Gemini 2.5, Veo 3.1, Imagen 3, Lyria 3 — + YouTube API para footage real
- Propietario: Jean Carlos (YANKYFILMS / MEDIAPLAYPROMO.COM)
- Maquina de desarrollo: GRANOSCAR (Windows 11, i7-13700K, RTX 4070 Ti 12GB, 96GB RAM)

## Comandos esenciales
- Instalar: npm install
- Desarrollo: npm run dev
- Build: npm run build
- Tests: npm run test
- Lint/Tipos: npm run lint && npm run typecheck
(Verificar contra package.json real del proyecto — estos son los comandos estandar de la mayoria de proyectos Next.js de Jean Carlos; ajustar si este proyecto usa otros scripts.)

## Reglas de arquitectura (lo que el codigo no deja ver a simple vista)
- Reconstruido alrededor del ecosistema Google AI — toda generacion de imagen/video/audio pasa por Gemini 2.5 / Veo 3.1 / Imagen 3 / Lyria 3; no mezclar con otros proveedores sin documentarlo aqui
- Busqueda de footage real via YouTube API — capa separada de la generacion sintetica
- Estetica 'brutal flow': tipografia Bebas Neue / Space Grotesk / Space Mono — no introducir otras familias sin actualizar este archivo

## Identidad visual (NO desviarse de esto)
- 'Brutal flow': negro profundo, rojo, ambar/dorado + tipografia Bebas Neue/Space Grotesk/Space Mono
- Cero placeholders. Entregables siempre listos para produccion.

## Carpetas que NUNCA se deben tocar
- node_modules/, .next/, dist/, build/, vendor/, out/

## Antes de marcar una tarea como completa
1. Correr lint + typecheck + tests
2. Verificar que no hay placeholders ni TODOs sin resolver
3. Actualizar PROJECT_STATE.md con lo que se hizo

## Idioma
- Comunicacion siempre en espanol
- Comentarios de codigo en ingles (estandar de la industria)

## Compact Instructions
Cuando resumas esta conversacion:
- Conserva todos los cambios de API y su razon
- Conserva mensajes de error y sus soluciones
- Mantén la lista de archivos modificados
- Resume brevemente los intentos de exploracion que no funcionaron
