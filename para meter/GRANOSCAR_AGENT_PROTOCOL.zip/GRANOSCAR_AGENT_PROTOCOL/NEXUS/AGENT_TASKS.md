# AGENT_TASKS.md — NEXUS

## Tarea actual de esta sesion
[PENDIENTE DE DEFINIR — completar al iniciar la proxima sesion con Codex/Claude Code]

Sugerencia segun el estado conocido del proyecto (ver PROJECT_STATE.md):
- Confirmar que panel(es) de NEXUS necesitan trabajo ahora; si todos estan completos, enfocar la sesion en QA o en una nueva automatizacion.

## Archivos que debe tocar
-

## Archivos que debe producir
-
