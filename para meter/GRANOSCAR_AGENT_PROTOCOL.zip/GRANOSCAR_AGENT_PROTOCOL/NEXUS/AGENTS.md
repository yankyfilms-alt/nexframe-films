# AGENTS.md / CLAUDE.md — NEXUS

## Identidad del proyecto
- Nombre: NEXUS
- Stack: Dashboard SaaS de gestion — 10 paneles
- Propietario: Jean Carlos (YANKYFILMS / MEDIAPLAYPROMO.COM)
- Maquina de desarrollo: GRANOSCAR (Windows 11, i7-13700K, RTX 4070 Ti 12GB, 96GB RAM)

## Comandos esenciales
- Instalar: npm install
- Desarrollo: npm run dev
- Build: npm run build
- Tests: npm run test
- Lint/Tipos: npm run lint && npm run typecheck
(Verificar contra package.json real del proyecto — estos son los comandos estandar de la mayoria de proyectos Next.js de Jean Carlos; ajustar si este proyecto usa otros scripts.)

## Reglas de arquitectura (lo que el codigo no deja ver a simple vista)
- 10 paneles independientes: clientes, afiliados, facturacion, licencias, automatizaciones, tienda, notificaciones (+ resto) — cada panel debe poder evolucionar sin romper a los demas
- Proyecto grande/multi-panel — usar .claudeignore agresivamente en subcarpetas pesadas para no agotar contexto

## Identidad visual (NO desviarse de esto)
- Paleta estandar YANKYFILMS: negro profundo, rojo, ambar/dorado
- Cero placeholders. Entregables siempre listos para produccion.

## Carpetas que NUNCA se deben tocar
- node_modules/, .next/, dist/, build/, vendor/, out/

## Antes de marcar una tarea como completa
1. Correr lint + typecheck + tests
2. Verificar que no hay placeholders ni TODOs sin resolver
3. Actualizar PROJECT_STATE.md con lo que se hizo

## Idioma
- Comunicacion siempre en espanol
- Comentarios de codigo en ingles (estandar de la industria)

## Compact Instructions
Cuando resumas esta conversacion:
- Conserva todos los cambios de API y su razon
- Conserva mensajes de error y sus soluciones
- Mantén la lista de archivos modificados
- Resume brevemente los intentos de exploracion que no funcionaron
