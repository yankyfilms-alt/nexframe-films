# Backlog.md — NEXUS

## Pendientes activos
- QA de los 10 paneles en produccion
- Documentar cada panel en docs/ con su proposito y dependencias

## Completados (archivo historico — mover aqui lo que se cierre, no lo borres)
-
