# Protocolo de contexto para agentes — GRANOSCAR
Generado a partir de tu GRANOSCAR_MASTER_STACK.pdf (Secciones 4, 11 y 12)

## Qué pude hacer y qué no, siendo honesto
Estoy operando desde el chat web, con un contenedor temporal que no es tu PC. No tengo
acceso al sistema de archivos de GRANOSCAR, así que no pude clonar repos, instalar paquetes
ni crear archivos directamente en tus carpetas de proyecto reales.

Lo que sí hice: te dejo **todos los archivos terminados**, listos para copiar a cada proyecto,
con `PROJECT_STATE.md` ya rellenado con el avance real que tengo registrado de nuestras
conversaciones (no genérico) — y un script `.ps1` para la única parte que sí es 100%
automatizable desde tu propia terminal en GRANOSCAR.

## Qué contiene esta carpeta

```
NEXFRAME_FILMS/      AGENTS.md, CLAUDE.md, PROJECT_STATE.md, AGENT_TASKS.md, Backlog.md, .claudeignore
AFFILIX/              (mismo set de 6 archivos)
YF_STUDIO_PRO/        (mismo set de 6 archivos)
PUBLIMASTER_IA/       (mismo set de 6 archivos)
NEXUS/                (mismo set de 6 archivos)
TEMPLATE_NUEVO_PROYECTO/   plantilla EN BLANCO (Sección 11) para cualquier proyecto futuro
                            (EXPEDIENTE 47, CÓDIGO BLANCO, DocuForge AI, GRANOSCAR MCP MAESTRO, etc.)
CHEATSHEET.md         los 2 prompts de "arranque heredado" y "cierre de sesión" para copiar/pegar
Clone-ReferenceRepos.ps1   script para clonar shadcn/ui, design-resources-for-developers
                            y OWASP Cheat Sheet Series en GRANOSCAR
```

## Pasos en GRANOSCAR

1. **Copia cada carpeta de proyecto** dentro de la raíz real de ese repo. Por ejemplo, el
   contenido de `NEXFRAME_FILMS/` va directo en la carpeta raíz de tu proyecto NEXFRAME FILMS
   (donde está tu `package.json`). Repite con AFFILIX, YF_STUDIO_PRO, PUBLIMASTER_IA y NEXUS.

2. **Revisa `PROJECT_STATE.md` de cada proyecto antes de usarlo.** Lo rellené con lo que ya
   sé de nuestras conversaciones, pero soy un snapshot de memoria, no un sistema de control
   de versiones de tu código real — corrige cualquier cosa que haya quedado desactualizada
   o incompleta.

3. **Ejecuta el script de repos una sola vez.** Abre PowerShell en la carpeta donde guardes
   este paquete y corre:
   ```
   .\Clone-ReferenceRepos.ps1
   ```
   Esto clona los 3 repos de referencia en `%USERPROFILE%\GRANOSCAR_REFS` y te recuerda los
   `npm install` de Tailwind/Lucide/helmet (esos van por proyecto, no se pueden automatizar
   de forma global).

4. **De ahora en adelante**, pega el prompt de "arranque heredado" (ver `CHEATSHEET.md`) al
   abrir cualquier sesión nueva de Codex o Claude Code en uno de estos proyectos, y el prompt
   de "cierre de sesión" al terminar cualquier sesión donde avanzaste algo importante. Así
   `PROJECT_STATE.md` y `Backlog.md` se mantienen vivos sin que tengas que re-explicar nada.

5. **Para proyectos nuevos** que no estén en esta lista de 5, usa `TEMPLATE_NUEVO_PROYECTO/`
   como punto de partida y rellénalo siguiendo el mismo patrón.

## Nota sobre AGENTS.md y CLAUDE.md
Son archivos idénticos a propósito — uno lo lee Codex, el otro Claude Code. Si editas uno,
edita el otro igual (o crea un symlink si prefieres no duplicar mantenimiento).
