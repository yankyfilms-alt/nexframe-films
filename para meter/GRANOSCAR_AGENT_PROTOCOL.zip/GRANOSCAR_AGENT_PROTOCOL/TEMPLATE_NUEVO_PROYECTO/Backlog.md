# Backlog.md — [NOMBRE DEL PROYECTO]

## Pendientes activos
-

## Completados (archivo historico — mover aqui lo que se cierre, no lo borres)
-
