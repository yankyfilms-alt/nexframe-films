# AGENT_TASKS.md — [NOMBRE DEL PROYECTO]

## Tarea actual de esta sesion
[Que hay que construir]

## Archivos que debe tocar
-

## Archivos que debe producir
-
