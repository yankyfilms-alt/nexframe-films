# AGENTS.md / CLAUDE.md — [NOMBRE DEL PROYECTO]

## Identidad del proyecto
- Nombre: [ej. NEXFRAME FILMS]
- Stack: [ej. Next.js 14 + Supabase + Stripe/PayPal]
- Propietario: Jean Carlos (YANKYFILMS / MEDIAPLAYPROMO.COM)
- Maquina de desarrollo: GRANOSCAR (Windows 11, i7-13700K, RTX 4070 Ti 12GB, 96GB RAM)

## Comandos esenciales
- Instalar: [ej. npm install]
- Desarrollo: [ej. npm run dev]
- Build: [ej. npm run build]
- Tests: [ej. npm run test]
- Lint/Tipos: [ej. npm run lint && npm run typecheck]

## Reglas de arquitectura (lo que el codigo no deja ver a simple vista)
- [ej. Todo acceso a base de datos pasa por src/db/repository.ts]
- [ej. Los temas oscuros viven en src/themes/, no hardcodear colores]
- [ej. Multi-rol admin: ver src/lib/roles.ts antes de tocar permisos]

## Identidad visual (NO te desvies de esto)
- Paleta: negro profundo, rojo, ambar/dorado — estetica cinematografica oscura
- Tipografia: [ej. Bebas Neue / Space Grotesk / Space Mono]
- Cero placeholders. Entregables siempre listos para produccion.

## Carpetas que NUNCA se deben tocar
- node_modules/, .next/, dist/, build/, vendor/

## Antes de marcar una tarea como completa
1. Correr lint + typecheck + tests
2. Verificar que no hay placeholders ni TODOs sin resolver
3. Actualizar PROJECT_STATE.md con lo que se hizo

## Idioma
- Comunicacion siempre en espanol
- Comentarios de codigo en ingles (estandar de la industria)

## Compact Instructions
Cuando resumas esta conversacion:
- Conserva todos los cambios de API y su razon
- Conserva mensajes de error y sus soluciones
- Mantén la lista de archivos modificados
- Resume brevemente los intentos de exploracion que no funcionaron
