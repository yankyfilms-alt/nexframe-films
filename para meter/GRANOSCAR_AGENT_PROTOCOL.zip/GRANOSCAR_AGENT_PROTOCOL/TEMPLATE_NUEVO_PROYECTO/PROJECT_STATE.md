# PROJECT_STATE.md — [NOMBRE DEL PROYECTO]

Ultima actualizacion: [fecha]

## Que esta hecho
-

## Que esta a medias / en progreso
-

## Decisiones de arquitectura y por que
-

## Que queda pendiente
-
