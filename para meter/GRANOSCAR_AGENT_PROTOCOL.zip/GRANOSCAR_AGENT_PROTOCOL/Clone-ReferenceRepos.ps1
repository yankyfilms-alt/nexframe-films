<#
GRANOSCAR — Clonado de repos de referencia (checklist Seccion 12, GRANOSCAR_MASTER_STACK.pdf)
Ejecutar UNA SOLA VEZ en GRANOSCAR, en PowerShell. No requiere permisos de administrador
si Git ya esta instalado.

Que hace:
  1) Crea la carpeta %USERPROFILE%\GRANOSCAR_REFS
  2) Clona ahi shadcn/ui, design-resources-for-developers y OWASP Cheat Sheet Series
     (los 3 repos que el checklist marca como referencia local obligatoria)
  3) Te recuerda los paquetes npm a instalar EN CADA proyecto que los necesite
     (Tailwind, Lucide, helmet — esto es por proyecto, no global, por eso no se automatiza aqui)

Uso:
  cd a la carpeta donde guardaste este script
  .\Clone-ReferenceRepos.ps1
#>

$ErrorActionPreference = "Stop"

if (-not (Get-Command git -ErrorAction SilentlyContinue)) {
    Write-Host "Git no esta instalado o no esta en el PATH. Instalalo primero (https://git-scm.com/download/win)." -ForegroundColor Red
    exit 1
}

$refDir = Join-Path $env:USERPROFILE "GRANOSCAR_REFS"
New-Item -ItemType Directory -Force -Path $refDir | Out-Null
Set-Location $refDir

Write-Host "Carpeta de referencias: $refDir" -ForegroundColor Cyan

$repos = @(
    "https://github.com/shadcn-ui/ui.git",
    "https://github.com/bradtraversy/design-resources-for-developers.git",
    "https://github.com/OWASP/CheatSheetSeries.git"
)

foreach ($repo in $repos) {
    $name = ($repo -split '/')[-1] -replace '\.git$', ''
    $target = Join-Path $refDir $name
    if (Test-Path $target) {
        Write-Host "[OK] $name ya existe, omitiendo clonado." -ForegroundColor Yellow
    } else {
        Write-Host "Clonando $name ..." -ForegroundColor Cyan
        git clone --depth 1 $repo
    }
}

Write-Host "`n--------------------------------------------------------------" -ForegroundColor DarkGray
Write-Host "Listo. Repos de referencia disponibles en: $refDir" -ForegroundColor Green
Write-Host "`nRecordatorio — esto NO es global, instalalo EN CADA proyecto Next.js/Node" -ForegroundColor Yellow
Write-Host "que lo necesite, desde la raiz de ese proyecto:" -ForegroundColor Yellow
Write-Host "  npm install -D tailwindcss"
Write-Host "  npm install lucide-react"
Write-Host "  npm install helmet"
Write-Host "--------------------------------------------------------------" -ForegroundColor DarkGray
