# CHEATSHEET — Prompts del protocolo de herencia de contexto
(Basado en la Seccion 4 de GRANOSCAR_MASTER_STACK.pdf)

## 1) Al ABRIR una sesion nueva en un proyecto existente

Pega esto al inicio, en la raiz del proyecto, antes de pedir nada mas:

---
Antes de hacer nada, lee completos en este orden: AGENTS.md, PROJECT_STATE.md, AGENT_TASKS.md
y Backlog.md. Actua como si tu mismo hubieras construido este sistema en sesiones anteriores:
no preguntes por contexto que ya esta documentado en esos archivos, no repitas exploracion ya
hecha, y continua exactamente desde donde quedo AGENT_TASKS.md. Si algo no esta claro despues
de leer los 4 archivos, pregunta solo eso, una vez.
---

## 2) Al CERRAR una sesion donde se avanzo algo relevante

---
Antes de terminar, actualiza PROJECT_STATE.md con: que se completo esta sesion, que decisiones
de arquitectura se tomaron y por que, y que queda pendiente. Actualiza tambien Backlog.md
quitando lo completado y anadiendo lo nuevo que haya surgido.
---

## Regla de oro
La memoria no vive en la cuenta de OpenAI/Anthropic. Vive en estos 4 archivos, versionados
en el repositorio. Cualquier Codex o Claude Code nuevo —otra maquina, otra cuenta, otro
modelo— puede "despertar" dentro del proyecto leyendo solo estos 4 archivos.
