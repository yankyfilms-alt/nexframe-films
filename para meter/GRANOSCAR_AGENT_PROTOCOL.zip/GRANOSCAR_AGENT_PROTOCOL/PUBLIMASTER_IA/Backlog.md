# Backlog.md — PUBLIMASTER IA (antes FlyerForge AI)

## Pendientes activos
- Barrido de referencias antiguas a FlyerForge AI
- Verificar automatizacion WhatsApp + email end-to-end

## Completados (archivo historico — mover aqui lo que se cierre, no lo borres)
-
