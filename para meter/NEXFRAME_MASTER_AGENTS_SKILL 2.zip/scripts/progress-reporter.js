/**
 * NEXFRAME FILMS — progress-reporter.js
 * ------------------------------------------------------------
 * Reporta progreso REAL de un ensamblaje largo (documental de 30 min,
 * video musical largo) al job guardado en la base, para que el panel
 * "Generation Process" del frontend pueda mostrar avance real en vez
 * de una barra de carga indefinida o un "colgado" sin info.
 *
 * Etapas estándar de un pipeline de Documentary/Music Video:
 *   script -> scenes -> generating_assets -> normalizing ->
 *   concatenating -> mixing_audio -> exporting -> completed
 *
 * Instalar en: /server/agents/progress-reporter.js
 * ------------------------------------------------------------
 */

'use strict';

const { updateJobProgress } = require('./db-adapter');

const PIPELINE_STAGES = [
  'script',
  'scenes',
  'generating_assets',
  'normalizing',
  'concatenating',
  'mixing_audio',
  'exporting',
  'completed',
];

function stageIndex(stage) {
  const idx = PIPELINE_STAGES.indexOf(stage);
  return idx === -1 ? 0 : idx;
}

/**
 * Reporta el avance de UNA etapa del pipeline. percentWithinStage es 0-100
 * y representa avance DENTRO de esa etapa (ej. "normalizando escena 4 de 12").
 */
async function reportProgress(jobId, stage, percentWithinStage = 0, extra = {}) {
  const idx = stageIndex(stage);
  const overallPercent = Math.round(
    ((idx + percentWithinStage / 100) / (PIPELINE_STAGES.length - 1)) * 100,
  );

  return updateJobProgress(jobId, {
    status: stage === 'completed' ? 'completed' : 'processing',
    stage,
    stagePercent: percentWithinStage,
    overallPercent: Math.min(100, Math.max(0, overallPercent)),
    ...extra,
  });
}

/**
 * Marca el job como fallido EN UNA ETAPA ESPECÍFICA, conservando qué tanto
 * avanzó antes de fallar — para que el usuario sepa exactamente qué se
 * perdió y qué no, en vez de un "error genérico" sin contexto.
 */
async function reportFailure(jobId, stage, errorMessage, partialResults = {}) {
  return updateJobProgress(jobId, {
    status: 'failed',
    stage,
    error: errorMessage,
    partialResults, // ej. { scenesCompleted: 6, scenesTotal: 12, scenePaths: [...] }
  });
}

/**
 * Helper específico para reportar "escena X de N" dentro de la etapa
 * generating_assets — el caso más común de necesitar feedback granular.
 */
async function reportSceneProgress(jobId, stage, sceneIndex, totalScenes) {
  const percentWithinStage = Math.round((sceneIndex / totalScenes) * 100);
  return reportProgress(jobId, stage, percentWithinStage, {
    sceneProgress: `${sceneIndex}/${totalScenes}`,
  });
}

module.exports = {
  PIPELINE_STAGES,
  reportProgress,
  reportFailure,
  reportSceneProgress,
};
