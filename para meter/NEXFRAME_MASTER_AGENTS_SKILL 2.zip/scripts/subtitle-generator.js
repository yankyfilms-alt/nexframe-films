/**
 * NEXFRAME FILMS — subtitle-generator.js
 * ------------------------------------------------------------
 * Genera subtítulos broadcast-standard para el entregable final de
 * Documentary Studio / Music Video Studio, siguiendo el formato ya
 * definido por YANKYFILMS (estándar EXPEDIENTE 47 / CÓDIGO BLANCO):
 *   - Frase por frase (no oraciones completas largas)
 *   - Máximo 2 líneas por subtítulo
 *   - 42 caracteres por línea
 *   - Fuente Oswald Bold
 *   - Fondo semi-transparente
 *
 * Usa el audio de narración + su transcripción con timestamps
 * (WhisperX, ya parte del stack GRANOSCAR) para generar el .srt/.ass
 * sincronizado, y quema los subtítulos en el video final con FFmpeg.
 *
 * Instalar en: /server/agents/subtitle-generator.js
 * ------------------------------------------------------------
 */

'use strict';

const fs = require('fs');
const { spawn } = require('child_process');

const MAX_CHARS_PER_LINE = 42;
const MAX_LINES_PER_SUBTITLE = 2;
const SUBTITLE_FONT = 'Oswald-Bold';

// ============================================================
// 1. PARTIR TEXTO EN LÍNEAS DE MÁXIMO 42 CARACTERES
//    (wrap por palabra completa, nunca corta una palabra a la mitad)
// ============================================================
function wrapTextToLines(text, maxChars = MAX_CHARS_PER_LINE) {
  const words = text.trim().split(/\s+/);
  const lines = [];
  let current = '';

  words.forEach((word) => {
    const candidate = current ? `${current} ${word}` : word;
    if (candidate.length > maxChars) {
      if (current) lines.push(current);
      current = word;
    } else {
      current = candidate;
    }
  });
  if (current) lines.push(current);
  return lines;
}

// ============================================================
// 2. AGRUPAR PALABRAS CON TIMESTAMP (de WhisperX) EN SUBTÍTULOS
//    DE MÁXIMO 2 LÍNEAS, RESPETANDO PAUSAS NATURALES.
//    wordTimestamps: [{ word, start, end }] (formato típico de WhisperX)
// ============================================================
function buildSubtitleBlocks(wordTimestamps, {
  maxCharsPerLine = MAX_CHARS_PER_LINE,
  maxLinesPerBlock = MAX_LINES_PER_SUBTITLE,
  maxBlockDurationSec = 5,
} = {}) {
  const blocks = [];
  let currentWords = [];
  let blockStart = null;

  const flushBlock = (endTime) => {
    if (currentWords.length === 0) return;
    const text = currentWords.join(' ');
    const lines = wrapTextToLines(text, maxCharsPerLine).slice(0, maxLinesPerBlock);
    blocks.push({ start: blockStart, end: endTime, lines });
    currentWords = [];
    blockStart = null;
  };

  wordTimestamps.forEach((wt, idx) => {
    if (blockStart === null) blockStart = wt.start;
    currentWords.push(wt.word);

    const candidateText = currentWords.join(' ');
    const wouldNeedLines = wrapTextToLines(candidateText, maxCharsPerLine).length;
    const duration = wt.end - blockStart;
    const isLastWord = idx === wordTimestamps.length - 1;
    const endsWithPunctuation = /[.!?]$/.test(wt.word);

    if (
      wouldNeedLines > maxLinesPerBlock
      || duration >= maxBlockDurationSec
      || isLastWord
      || (endsWithPunctuation && currentWords.length > 4)
    ) {
      if (wouldNeedLines > maxLinesPerBlock) {
        // la última palabra desbordó: la regresamos al siguiente bloque
        currentWords.pop();
        flushBlock(wordTimestamps[idx - 1] ? wordTimestamps[idx - 1].end : wt.start);
        currentWords = [wt.word];
        blockStart = wt.start;
        if (isLastWord) flushBlock(wt.end);
      } else {
        flushBlock(wt.end);
      }
    }
  });

  flushBlock(wordTimestamps.length ? wordTimestamps[wordTimestamps.length - 1].end : 0);
  return blocks;
}

// ============================================================
// 3. EXPORTAR A FORMATO .SRT
// ============================================================
function formatSrtTimestamp(seconds) {
  const ms = Math.round((seconds % 1) * 1000);
  const totalSec = Math.floor(seconds);
  const h = Math.floor(totalSec / 3600);
  const m = Math.floor((totalSec % 3600) / 60);
  const s = totalSec % 60;
  const pad = (n, len = 2) => String(n).padStart(len, '0');
  return `${pad(h)}:${pad(m)}:${pad(s)},${pad(ms, 3)}`;
}

function buildSrt(blocks) {
  return blocks
    .map((b, idx) => {
      const text = b.lines.join('\n');
      return `${idx + 1}\n${formatSrtTimestamp(b.start)} --> ${formatSrtTimestamp(b.end)}\n${text}\n`;
    })
    .join('\n');
}

function writeSrtFile(blocks, outputPath) {
  fs.writeFileSync(outputPath, buildSrt(blocks), 'utf8');
  return outputPath;
}

// ============================================================
// 4. QUEMAR SUBTÍTULOS EN EL VIDEO FINAL (estilo broadcast)
//    Fuente Oswald Bold, fondo semi-transparente, vía libass de FFmpeg.
// ============================================================
function runFFmpeg(args) {
  return new Promise((resolve, reject) => {
    const proc = spawn('ffmpeg', ['-y', ...args]);
    let stderr = '';
    proc.stderr.on('data', (d) => { stderr += d.toString(); });
    proc.on('close', (code) => (code === 0 ? resolve({ ok: true }) : reject(new Error(stderr.slice(-1500)))));
    proc.on('error', (err) => reject(err));
  });
}

async function burnSubtitlesOnVideo(videoPath, srtPath, outputPath, {
  fontName = SUBTITLE_FONT,
  fontSize = 24,
  backgroundOpacity = 0.55, // semi-transparente
} = {}) {
  // BackColour en formato ASS: &HAABBGGRR — alpha calculado desde backgroundOpacity
  const alphaHex = Math.round((1 - backgroundOpacity) * 255).toString(16).padStart(2, '0');
  const forceStyle = [
    `FontName=${fontName}`,
    `FontSize=${fontSize}`,
    'BorderStyle=3', // caja de fondo (no solo contorno)
    `BackColour=&H${alphaHex}000000`,
    'Alignment=2', // centrado abajo
  ].join(',');

  const args = [
    '-i', videoPath,
    '-vf', `subtitles=${srtPath}:force_style='${forceStyle}'`,
    '-c:v', 'libx264',
    '-preset', 'fast',
    '-crf', '18',
    '-c:a', 'copy',
    outputPath,
  ];
  await runFFmpeg(args);
  return outputPath;
}

// ============================================================
// 5. PIPELINE COMPLETO: timestamps -> bloques -> .srt -> quemado
// ============================================================
async function generateAndBurnSubtitles(wordTimestamps, videoPath, outputPath, workDir) {
  const blocks = buildSubtitleBlocks(wordTimestamps);
  const srtPath = `${workDir}/subtitles-${Date.now()}.srt`;
  writeSrtFile(blocks, srtPath);
  await burnSubtitlesOnVideo(videoPath, srtPath, outputPath);
  return { srtPath, outputPath, blockCount: blocks.length };
}

module.exports = {
  MAX_CHARS_PER_LINE,
  MAX_LINES_PER_SUBTITLE,
  SUBTITLE_FONT,
  wrapTextToLines,
  buildSubtitleBlocks,
  buildSrt,
  writeSrtFile,
  burnSubtitlesOnVideo,
  generateAndBurnSubtitles,
};
