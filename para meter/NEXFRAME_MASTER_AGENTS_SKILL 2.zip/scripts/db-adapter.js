/**
 * NEXFRAME FILMS — db-adapter.js
 * ------------------------------------------------------------
 * Adaptador real de persistencia sobre data/nexframe-db.json
 * (el storage local que ya define el documento de orden funcional
 * de NEXFRAME). Expone getProject/saveProject que necesita
 * agents-registry.js (resolveCharacterConsistency) y cualquier
 * otro módulo que necesite leer/escribir estado de un proyecto.
 *
 * Usa un lock simple de escritura en archivo para evitar que dos
 * requests concurrentes pisen el mismo JSON (problema real con
 * JSON-como-base-de-datos bajo carga concurrente).
 *
 * Instalar en: /server/agents/db-adapter.js
 *
 * Si el proyecto migra a una base real (Postgres/Supabase/Prisma),
 * solo hay que reimplementar estas 4 funciones — el resto del
 * sistema de agentes no cambia, porque todos dependen de esta
 * interfaz, no del archivo JSON directamente.
 * ------------------------------------------------------------
 */

'use strict';

const fs = require('fs');
const path = require('path');

const DB_PATH = process.env.NEXFRAME_DB_PATH || path.join(process.cwd(), 'data', 'nexframe-db.json');

let writeLock = Promise.resolve(); // cola simple de escrituras secuenciales

function readDbRaw() {
  if (!fs.existsSync(DB_PATH)) {
    return { users: [], projects: [], jobs: [], usage: {} };
  }
  const raw = fs.readFileSync(DB_PATH, 'utf8');
  try {
    return JSON.parse(raw || '{}');
  } catch (err) {
    throw new Error(`nexframe-db.json corrupto o no es JSON válido: ${err.message}`);
  }
}

function writeDbRaw(data) {
  const dir = path.dirname(DB_PATH);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  // Escritura atómica: a archivo temporal, luego rename — evita un JSON a medio
  // escribir si el proceso se cae justo durante el guardado.
  const tmpPath = `${DB_PATH}.tmp-${process.pid}-${Date.now()}`;
  fs.writeFileSync(tmpPath, JSON.stringify(data, null, 2), 'utf8');
  fs.renameSync(tmpPath, DB_PATH);
}

function withWriteLock(fn) {
  const result = writeLock.then(() => fn());
  writeLock = result.catch(() => {}); // no romper la cola si una escritura falla
  return result;
}

// ============================================================
// API PÚBLICA — usada por agents-registry.js y los Studios
// ============================================================

function getProject(projectId) {
  const db = readDbRaw();
  return (db.projects || []).find((p) => p.id === projectId) || null;
}

async function saveProject(projectId, data) {
  return withWriteLock(() => {
    const db = readDbRaw();
    db.projects = db.projects || [];
    const idx = db.projects.findIndex((p) => p.id === projectId);
    const updated = { id: projectId, ...data, updatedAt: new Date().toISOString() };
    if (idx >= 0) {
      db.projects[idx] = { ...db.projects[idx], ...updated };
    } else {
      db.projects.push({ ...updated, createdAt: new Date().toISOString() });
    }
    writeDbRaw(db);
    return db.projects[idx >= 0 ? idx : db.projects.length - 1];
  });
}

function getJob(jobId) {
  const db = readDbRaw();
  return (db.jobs || []).find((j) => j.id === jobId) || null;
}

async function saveJob(jobId, data) {
  return withWriteLock(() => {
    const db = readDbRaw();
    db.jobs = db.jobs || [];
    const idx = db.jobs.findIndex((j) => j.id === jobId);
    const updated = { id: jobId, ...data, updatedAt: new Date().toISOString() };
    if (idx >= 0) {
      db.jobs[idx] = { ...db.jobs[idx], ...updated };
    } else {
      db.jobs.push({ ...updated, createdAt: new Date().toISOString() });
    }
    writeDbRaw(db);
    return db.jobs[idx >= 0 ? idx : db.jobs.length - 1];
  });
}

/**
 * Actualiza solo un campo de progreso del job sin pisar el resto del objeto.
 * Pensado para reportar avance de ensamblaje largo (ver progress-reporter.js).
 */
async function updateJobProgress(jobId, progressPatch) {
  const current = getJob(jobId) || { id: jobId };
  return saveJob(jobId, { ...current, ...progressPatch });
}

module.exports = {
  DB_PATH,
  getProject,
  saveProject,
  getJob,
  saveJob,
  updateJobProgress,
};
