/**
 * NEXFRAME FILMS — pipeline-orchestrator.js
 * ------------------------------------------------------------
 * EL MÓDULO QUE CONECTA TODO. Esto es lo que realmente se llama
 * desde /api/generate y /api/muapi/generate/pipeline — orquesta,
 * en el orden correcto, a:
 *   agents-registry.js    (qué modelo/parámetros usar)
 *   db-adapter.js          (persistencia real del proyecto/job)
 *   progress-reporter.js   (progreso en tiempo real)
 *   upload-classifier.js   (referencias subidas por el usuario)
 *   video-assembly-pipeline.js (ensamblaje final con FFmpeg)
 *
 * Sin este archivo, los otros 5 módulos son piezas sueltas que
 * Codex tendría que conectar a mano — aquí ya está conectado.
 *
 * Instalar en: /server/agents/pipeline-orchestrator.js
 * ------------------------------------------------------------
 */

'use strict';

const {
  selectAgentForStudio,
  resolveCharacterConsistency,
  validateProjectConsistency,
  validateAgentOutput,
  sanitizeTextForTTS,
} = require('./agents-registry');

const { getProject, saveProject, saveJob, updateJobProgress } = require('./db-adapter');
const { reportProgress, reportFailure, reportSceneProgress } = require('./progress-reporter');
const { assembleFinalVideo } = require('./video-assembly-pipeline');
const { classifyUploadBatch, buildTextContextBlock } = require('./upload-classifier');

// ============================================================
// CONFIGURACIÓN DE REINTENTOS — qué hacer si MuAPI falla a media
// generación de un documental/videoclip largo de muchas escenas.
// ============================================================
const MAX_RETRIES_PER_SCENE = 2;
const RETRY_DELAY_MS = 3000;

function sleep(ms) { return new Promise((resolve) => setTimeout(resolve, ms)); }

// ============================================================
// 1. GENERACIÓN SIMPLE (un solo Studio, una sola llamada)
//    Esto es lo que usan Image/Video/Sound/Effects/Lip Sync Studio.
// ============================================================
/**
 * callMuApi: función que el backend YA tiene (el gateway MuAPI existente
 * del proyecto) — esta función no la reemplaza, solo decide qué mandarle.
 * Firma esperada: async (model, params, medias) => muapiResponse
 */
async function runSimpleGeneration({ studioName, userPrompt, projectContext, requestedCount, callMuApi, jobId }) {
  const decision = selectAgentForStudio(studioName, userPrompt, projectContext);

  await reportProgress(jobId, 'generating_assets', 0, { model: decision.model, notes: decision.notes });

  let lastError = null;
  for (let attempt = 0; attempt <= MAX_RETRIES_PER_SCENE; attempt += 1) {
    try {
      const muapiResponse = await callMuApi(decision.model, decision.params, decision.medias || []);
      const check = validateAgentOutput(decision, muapiResponse, requestedCount);

      if (!check.ok) {
        lastError = new Error(check.issues.join(' | '));
        if (attempt < MAX_RETRIES_PER_SCENE) {
          await sleep(RETRY_DELAY_MS);
          continue;
        }
      }

      await reportProgress(jobId, 'completed', 100, { outputs: check.outputs, issues: check.issues });
      return { ok: check.ok, outputs: check.outputs, issues: check.issues, model: decision.model };
    } catch (err) {
      lastError = err;
      if (attempt < MAX_RETRIES_PER_SCENE) {
        await sleep(RETRY_DELAY_MS);
      }
    }
  }

  await reportFailure(jobId, 'generating_assets', lastError ? lastError.message : 'Error desconocido tras reintentos.');
  return { ok: false, outputs: [], issues: [lastError ? lastError.message : 'fallo desconocido'], model: decision.model };
}

// ============================================================
// 2. PIPELINE COMPUESTO LARGO — Documentary / Music Video
//    Resuelve: consistencia de personaje, progreso real, fallo
//    parcial sin perder lo ya generado, y ensamblaje final.
// ============================================================
/**
 * scenesPlan: [{ sceneId, prompt, transitionToNext }]
 * narrationScript: texto completo de narración (se sanitiza para TTS aquí)
 * musicTrackPath: ruta a la canción/música ya provista o generada
 * uploadedFiles: archivos subidos por el usuario (imágenes, PDF, audio, etc.)
 * callMuApi / callTtsApi: funciones del gateway MuAPI ya existentes en el backend
 */
async function runLongFormPipeline({
  projectId,
  jobId,
  studioName, // 'DocumentaryStudio' | 'MusicVideoStudio'
  scenesPlan,
  narrationScript,
  musicTrackPath,
  uploadedFiles = [],
  savedFilePaths = [],
  callMuApi,
  callTtsApi,
  fixedVoiceId = null,
}) {
  const issues = [];

  // --- Paso 0: clasificar todo lo que el usuario subió (imágenes, PDF, audio...) ---
  const uploadResult = await classifyUploadBatch(uploadedFiles, savedFilePaths);
  if (!uploadResult.validation.ok) {
    issues.push(...uploadResult.validation.issues);
  }
  const textContext = buildTextContextBlock(uploadResult.grouped);
  const referenceImage = uploadResult.grouped.visual_references[0] || null;

  // --- Paso 1: consistencia de personaje (si hay referencia visual subida) ---
  const consistency = resolveCharacterConsistency(
    projectId,
    referenceImage ? { referenceImageUrl: referenceImage.path, visualStyle: 'general' } : null,
    { getProject, saveProject },
  );

  await reportProgress(jobId, 'script', 100, { textContextIncluded: !!textContext });

  // --- Paso 2: generar cada escena, con reintentos, sin perder lo ya hecho ---
  const completedScenes = [];
  const totalScenes = scenesPlan.length;

  for (let i = 0; i < totalScenes; i += 1) {
    const scene = scenesPlan[i];
    await reportSceneProgress(jobId, 'generating_assets', i, totalScenes);

    const promptWithContext = textContext
      ? `${scene.prompt}\n\nContexto adicional del proyecto:\n${textContext}`
      : scene.prompt;

    const sceneResult = await runSimpleGeneration({
      studioName,
      userPrompt: promptWithContext,
      projectContext: {
        soulId: consistency.soulId,
        referenceImageUrl: consistency.referenceImageUrl,
        cinematic: studioName === 'DocumentaryStudio',
      },
      requestedCount: 1,
      callMuApi,
      jobId,
    });

    if (!sceneResult.ok) {
      // FALLO PARCIAL: se conserva lo ya generado, se reporta exactamente
      // qué escena falló y cuántas sí se completaron — NUNCA se descarta
      // el trabajo ya hecho.
      await reportFailure(jobId, 'generating_assets',
        `Escena ${scene.sceneId} falló tras reintentos: ${sceneResult.issues.join(' | ')}`,
        { scenesCompleted: completedScenes.length, scenesTotal: totalScenes, completedScenes });
      issues.push(`Escena ${scene.sceneId} no se pudo generar — el proyecto quedó PARCIAL (${completedScenes.length}/${totalScenes} escenas listas).`);
      return { ok: false, finalVideoPath: null, completedScenes, issues };
    }

    completedScenes.push({
      sceneId: scene.sceneId,
      videoPath: sceneResult.outputs[0] && sceneResult.outputs[0].path,
      soulId: consistency.soulId,
      visualStyle: 'general',
      transitionToNext: scene.transitionToNext || 'cut',
    });
  }

  // --- Paso 2.5: verificar que TODAS las escenas tienen un archivo de video
  // real en disco ANTES de llegar a FFmpeg. Si MuAPI devolvió una URL remota
  // en vez de una ruta local, el caller del backend (gateway MuAPI) debe
  // haber descargado el archivo y puesto la ruta local en outputs[0].path —
  // este chequeo existe para fallar con un mensaje claro en vez de un error
  // críptico de FFmpeg si ese paso de descarga se omitió.
  const fs = require('fs');
  const missingFiles = completedScenes.filter((s) => !s.videoPath || !fs.existsSync(s.videoPath));
  if (missingFiles.length > 0) {
    const missingIds = missingFiles.map((s) => s.sceneId).join(', ');
    await reportFailure(jobId, 'generating_assets',
      `Las escenas [${missingIds}] no tienen un archivo de video local válido (¿el gateway MuAPI descargó el resultado a disco?). No se puede ensamblar el video final sin esto.`,
      { scenesCompleted: completedScenes.length - missingFiles.length, scenesTotal: totalScenes, completedScenes });
    issues.push(`Archivos de video faltantes para: ${missingIds}. Verificar que el gateway MuAPI descarga cada output a disco antes de pasarlo al orquestador.`);
    return { ok: false, finalVideoPath: null, completedScenes, issues };
  }

  // --- Paso 3: verificar consistencia visual entre TODAS las escenas ---
  const consistencyCheck = validateProjectConsistency(completedScenes);
  if (!consistencyCheck.ok) {
    issues.push(...consistencyCheck.issues);
  }

  // --- Paso 4: narración (sanitizada para TTS, voz fija del proyecto/canal) ---
  await reportProgress(jobId, 'normalizing', 0);
  let narrationAudioPath = null;
  if (narrationScript) {
    const cleanScript = sanitizeTextForTTS(narrationScript);
    const ttsResponse = await callTtsApi(cleanScript, fixedVoiceId);
    narrationAudioPath = ttsResponse && ttsResponse.path;
    if (!narrationAudioPath) {
      issues.push('No se pudo generar la narración — el video final se ensamblará SIN voz; revisar antes de entregar como completo.');
    }
  }

  // --- Paso 5: ensamblaje final real con FFmpeg ---
  await reportProgress(jobId, 'concatenating', 0);
  const assembly = await assembleFinalVideo(
    completedScenes,
    narrationAudioPath,
    musicTrackPath,
    { workDir: `tmp-assembly-${projectId}` },
  );
  issues.push(...assembly.issues);

  await reportProgress(jobId, 'exporting', 100, { finalVideoPath: assembly.finalVideoPath });
  await reportProgress(jobId, 'completed', 100, { finalVideoPath: assembly.finalVideoPath, issues });

  return {
    ok: assembly.ok && issues.length === 0,
    finalVideoPath: assembly.finalVideoPath,
    completedScenes,
    issues,
  };
}

module.exports = {
  runSimpleGeneration,
  runLongFormPipeline,
};
