/**
 * quickActionsEndpoints.js
 * ============================================================
 * "ACCIONES RÁPIDAS" DEL PANEL DOCUMENTARY — VERSIÓN REAL.
 *
 * Cada botón suelto (Investigación, Narrativa, Guion, Escenas, Voz,
 * Música, Visuales) pasa a ejecutar la llamada real correspondiente
 * (MuAPI o local), en vez de devolver una estructura JSON predefinida.
 *
 * Reutiliza las MISMAS funciones internas que ya usa el pipeline
 * completo (documentaryPipeline.js) — no hay lógica duplicada. Si
 * mejoras un prompt o cambias un modelo en un sitio, se aplica en
 * ambos: el botón suelto y el pipeline completo de 10 etapas.
 *
 * CÓMO CONECTAR ESTO A TU server.js EXISTENTE:
 *
 *   const registerQuickActionRoutes = require("./quickActionsEndpoints");
 *   registerQuickActionRoutes(app); // una sola línea, registra las 7 rutas
 *
 * Cada acción es independiente y NO requiere que exista un job de
 * pipeline completo corriendo — el usuario puede pulsar "Investigación"
 * solo, ver el resultado, y luego decidir si sigue con "Narrativa".
 * ============================================================
 */

const fs = require("fs");
const path = require("path");
const { selectBestModel, callMuapi } = require("./muapiClient");
const { generateNarration, generateBackgroundMusic } = require("./localMediaClient");
const {
  buildResearchPrompt,
  buildNarrativePrompt,
  generateFullLengthScript,
  divideScriptIntoScenes,
  buildVisualPrompt,
  mapStyleToMood,
  generateSrtFromScript,
  getAudioDurationSeconds,
  DURATION_MAP_SECONDS,
} = require("./documentaryPipeline");

const SCRATCH_DIR = path.join(__dirname, "..", "public", "uploads", "documentary", "_quick");

function ensureScratchDir() {
  fs.mkdirSync(SCRATCH_DIR, { recursive: true });
}

/**
 * Registra las 7 rutas de acciones rápidas en tu app Express existente.
 * No toca ninguna ruta que ya tengas — solo añade estas 7.
 */
function registerQuickActionRoutes(app) {
  ensureScratchDir();

  // ── 1. INVESTIGACIÓN ──────────────────────────────────────
  app.post("/api/documentary/research", async (req, res) => {
    try {
      const { topic, description, language = "es", referenceFiles = [] } = req.body;
      if (!topic) return res.status(400).json({ ok: false, error: { message: "Falta 'topic' en la petición" } });

      const model = selectBestModel({ capability: "research", studio: "documentary" });
      const result = await callMuapi({
        modelId: model,
        input: { prompt: buildResearchPrompt(topic, description, language), referenceFiles },
      });

      res.json({ ok: true, model_used: model, result });
    } catch (err) {
      console.error("[/api/documentary/research] Error:", err.message);
      res.status(500).json({ ok: false, error: { message: err.message } });
    }
  });

  // ── 2. NARRATIVA ───────────────────────────────────────────
  app.post("/api/documentary/narrative", async (req, res) => {
    try {
      const { researchData, narrativeStyle = "investigative", durationKey = "40min", language = "es" } = req.body;
      if (!researchData) return res.status(400).json({ ok: false, error: { message: "Falta 'researchData' — ejecuta primero Investigación" } });

      const totalSeconds = DURATION_MAP_SECONDS[durationKey] || DURATION_MAP_SECONDS["40min"];
      const model = selectBestModel({ capability: "text-generation", studio: "documentary" });
      const result = await callMuapi({
        modelId: model,
        input: { prompt: buildNarrativePrompt(researchData, narrativeStyle, totalSeconds, language) },
      });

      res.json({ ok: true, model_used: model, result });
    } catch (err) {
      console.error("[/api/documentary/narrative] Error:", err.message);
      res.status(500).json({ ok: false, error: { message: err.message } });
    }
  });

  // ── 3. GUION COMPLETO ──────────────────────────────────────
  app.post("/api/documentary/script", async (req, res) => {
    try {
      const { researchData, narrativeData, durationKey = "40min", language = "es", narrativeStyle = "investigative" } = req.body;
      if (!researchData || !narrativeData) {
        return res.status(400).json({ ok: false, error: { message: "Faltan 'researchData' y/o 'narrativeData' — ejecuta primero Investigación y Narrativa" } });
      }

      const totalSeconds = DURATION_MAP_SECONDS[durationKey] || DURATION_MAP_SECONDS["40min"];
      const fullScript = await generateFullLengthScript({
        researchData,
        narrativeData,
        totalSeconds,
        language,
        narrativeStyle,
      });

      res.json({ ok: true, result: { text: fullScript.text, wordCount: fullScript.wordCount } });
    } catch (err) {
      console.error("[/api/documentary/script] Error:", err.message);
      res.status(500).json({ ok: false, error: { message: err.message } });
    }
  });

  // ── 4. ESCENAS ──────────────────────────────────────────────
  app.post("/api/documentary/scenes", async (req, res) => {
    try {
      const { scriptText, durationKey = "40min" } = req.body;
      if (!scriptText) return res.status(400).json({ ok: false, error: { message: "Falta 'scriptText' — ejecuta primero Guion" } });

      const totalSeconds = DURATION_MAP_SECONDS[durationKey] || DURATION_MAP_SECONDS["40min"];
      const scenes = divideScriptIntoScenes(scriptText, totalSeconds);

      res.json({ ok: true, result: { scenes, sceneCount: scenes.length } });
    } catch (err) {
      console.error("[/api/documentary/scenes] Error:", err.message);
      res.status(500).json({ ok: false, error: { message: err.message } });
    }
  });

  // ── 5. VOZ ───────────────────────────────────────────────────
  app.post("/api/documentary/voiceover", async (req, res) => {
    try {
      const { scriptText, language = "es", voiceId = "default" } = req.body;
      if (!scriptText) return res.status(400).json({ ok: false, error: { message: "Falta 'scriptText' — ejecuta primero Guion" } });

      const outputPath = path.join(SCRATCH_DIR, `voice_${Date.now()}.wav`);
      await generateNarration({ scriptText, outputPath, language, voiceId });
      const durationSeconds = await getAudioDurationSeconds(outputPath);

      res.json({
        ok: true,
        result: {
          audioUrl: toPublicUrl(outputPath),
          durationSeconds,
        },
      });
    } catch (err) {
      console.error("[/api/documentary/voiceover] Error:", err.message);
      res.status(500).json({ ok: false, error: { message: err.message } });
    }
  });

  // ── 6. MÚSICA ─────────────────────────────────────────────────
  app.post("/api/documentary/music", async (req, res) => {
    try {
      const { durationSeconds, narrativeStyle = "investigative" } = req.body;
      if (!durationSeconds) {
        return res.status(400).json({ ok: false, error: { message: "Falta 'durationSeconds' — ejecuta primero Voz para obtener la duración real" } });
      }

      const outputPath = path.join(SCRATCH_DIR, `music_${Date.now()}.wav`);
      await generateBackgroundMusic({
        durationSeconds,
        mood: mapStyleToMood(narrativeStyle),
        outputPath,
      });

      res.json({ ok: true, result: { audioUrl: toPublicUrl(outputPath) } });
    } catch (err) {
      console.error("[/api/documentary/music] Error:", err.message);
      res.status(500).json({ ok: false, error: { message: err.message } });
    }
  });

  // ── 7. VISUALES ────────────────────────────────────────────────
  app.post("/api/documentary/visuals", async (req, res) => {
    try {
      const { scenes, visualStyle = "cinematic-documentary", referenceFiles = [] } = req.body;
      if (!scenes || !Array.isArray(scenes) || scenes.length === 0) {
        return res.status(400).json({ ok: false, error: { message: "Falta 'scenes' (array) — ejecuta primero Escenas" } });
      }

      const model = selectBestModel({ capability: "image-generation", studio: "documentary" });
      const sceneVisuals = [];

      for (let i = 0; i < scenes.length; i++) {
        const visual = await callMuapi({
          modelId: model,
          input: {
            prompt: buildVisualPrompt(scenes[i], visualStyle),
            referenceFiles: referenceFiles.filter((f) => f.type === "image"),
          },
        });
        sceneVisuals.push({ sceneIndex: i, ...visual });
      }

      res.json({ ok: true, model_used: model, result: { sceneVisuals, count: sceneVisuals.length } });
    } catch (err) {
      console.error("[/api/documentary/visuals] Error:", err.message);
      res.status(500).json({ ok: false, error: { message: err.message } });
    }
  });

  // ── BONUS: SUBTÍTULOS sueltos (no estaba en tu lista original
  //          de acciones rápidas, pero te lo dejo por si lo añades) ──
  app.post("/api/documentary/subtitles", async (req, res) => {
    try {
      const { scriptText, durationSeconds } = req.body;
      if (!scriptText || !durationSeconds) {
        return res.status(400).json({ ok: false, error: { message: "Faltan 'scriptText' y 'durationSeconds' — ejecuta primero Guion y Voz" } });
      }

      const srtContent = generateSrtFromScript(scriptText, durationSeconds);
      const outputPath = path.join(SCRATCH_DIR, `subs_${Date.now()}.srt`);
      fs.writeFileSync(outputPath, srtContent);

      res.json({ ok: true, result: { srtUrl: toPublicUrl(outputPath), srtContent } });
    } catch (err) {
      console.error("[/api/documentary/subtitles] Error:", err.message);
      res.status(500).json({ ok: false, error: { message: err.message } });
    }
  });

  console.log("[quickActionsEndpoints] 7 rutas de Acciones Rápidas registradas: " +
    "/api/documentary/{research,narrative,script,scenes,voiceover,music,visuals,subtitles}");
}

/**
 * Convierte una ruta absoluta del filesystem en una URL pública servible.
 * AJUSTA esto si tu Express no sirve estáticos desde "public/" directamente,
 * o si usas otro prefijo de ruta para archivos estáticos.
 */
function toPublicUrl(absolutePath) {
  const publicRoot = path.join(__dirname, "..", "public");
  const relative = path.relative(publicRoot, absolutePath).split(path.sep).join("/");
  return `/${relative}`;
}

module.exports = registerQuickActionRoutes;
