/**
 * documentaryPipeline.js
 * ============================================================
 * PIPELINE MAESTRO DEL DOCUMENTARY STUDIO — VERSIÓN REAL.
 *
 * Sustituye la simulación local (texto del tema + FFmpeg con fondo
 * oscuro fijo) por las 10 etapas reales descritas en App.jsx:
 *
 *   1. Research      → MuAPI (auto-selección de modelo de texto/research)
 *   2. Narrativa      → MuAPI (estructura narrativa a partir del research)
 *   3. Guion          → MuAPI (guion COMPLETO ajustado a la duración real)
 *   4. Escenas        → derivado del guion (división temporal real)
 *   5. Voz            → LOCAL (XTTS/Kokoro) — narración completa
 *   6. Música         → LOCAL (ACE-Step/YuE) — ajustada a duración real
 *   7. Visuales       → MuAPI (una imagen/clip por escena, no un fondo fijo)
 *   8. Subtítulos     → generado desde el guion + timestamps reales de audio
 *   9. Montaje        → FFmpeg real: resolución/formato del panel, NVENC
 *  10. Exportación    → MP4 final + manifest + permite descargar el MP4 real
 *
 * CÓMO CONECTAR ESTO A TU server.js EXISTENTE:
 *
 *   const { runDocumentaryPipeline } = require("./documentaryPipeline");
 *
 *   // Dentro de tu handler existente de POST /api/muapi/pipeline,
 *   // cuando studio === "documentary":
 *   app.post("/api/muapi/pipeline", async (req, res) => {
 *     const { studio, ...config } = req.body;
 *     if (studio === "documentary") {
 *       const jobId = createJobRecord(...); // tu función existente de jobs
 *       res.json({ ok: true, job_id: jobId, status: "queued" }); // responde YA
 *       runDocumentaryPipeline(config, jobId, updateJobProgress) // procesa async
 *         .catch(err => markJobFailed(jobId, err));
 *       return;
 *     }
 *     // ...resto de tus studios existentes
 *   });
 *
 * `updateJobProgress(jobId, stageName, percent, data)` es tu función
 * existente que actualiza el estado del job para que el frontend (que
 * ya hace polling a /api/task/:id) lo vea avanzar etapa por etapa.
 * Si no la tienes así de genérica, dime cómo está hecha y la adapto.
 * ============================================================
 */

const fs = require("fs");
const path = require("path");
const { execFile } = require("child_process");
const { selectBestModel, callMuapi } = require("./muapiClient");
const { generateNarration, generateBackgroundMusic } = require("./localMediaClient");

const OUTPUT_DIR = path.join(__dirname, "..", "public", "uploads", "documentary");

// Mapeo de duración de panel → segundos reales
const DURATION_MAP_SECONDS = {
  "30min": 30 * 60,
  "40min": 40 * 60,
  "60min": 60 * 60,
};

// Mapeo de resolución/formato del panel → dimensiones reales de salida
const RESOLUTION_MAP = {
  "1080x1920": { width: 1080, height: 1920 }, // vertical (shorts/reels)
  "1920x1080": { width: 1920, height: 1080 }, // horizontal (YouTube estándar)
  "3840x2160": { width: 3840, height: 2160 }, // 4K horizontal
};

/**
 * Punto de entrada principal. Ejecuta las 10 etapas en orden,
 * reportando progreso real en cada una.
 */
async function runDocumentaryPipeline(config, jobId, updateJobProgress) {
  const {
    topic,
    description,
    durationKey = "40min",
    resolutionKey = "1920x1080",
    language = "es",
    narrativeStyle = "investigative",
    visualStyle = "cinematic-documentary",
    referenceFiles = [], // audio/imagen/video/documento subido por el usuario
  } = config;

  const totalSeconds = DURATION_MAP_SECONDS[durationKey] || DURATION_MAP_SECONDS["40min"];
  const { width, height } = RESOLUTION_MAP[resolutionKey] || RESOLUTION_MAP["1920x1080"];

  const workDir = path.join(OUTPUT_DIR, jobId);
  fs.mkdirSync(workDir, { recursive: true });

  const progress = (stage, percent, data) => {
    console.log(`[Documentary:${jobId}] ${stage} — ${percent}%`);
    updateJobProgress(jobId, stage, percent, data);
  };

  try {
    // ── ETAPA 1: RESEARCH ──────────────────────────────────
    progress("research", 5);
    const researchModel = selectBestModel({ capability: "research", studio: "documentary" });
    const researchData = await callMuapi({
      modelId: researchModel,
      input: {
        prompt: buildResearchPrompt(topic, description, language),
        referenceFiles,
      },
    });
    fs.writeFileSync(path.join(workDir, "research.json"), JSON.stringify(researchData, null, 2));
    progress("research", 10, { summary: summarize(researchData) });

    // ── ETAPA 2: NARRATIVA ─────────────────────────────────
    progress("narrative", 12);
    const narrativeModel = selectBestModel({ capability: "text-generation", studio: "documentary" });
    const narrativeData = await callMuapi({
      modelId: narrativeModel,
      input: {
        prompt: buildNarrativePrompt(researchData, narrativeStyle, totalSeconds, language),
      },
    });
    fs.writeFileSync(path.join(workDir, "narrative.json"), JSON.stringify(narrativeData, null, 2));
    progress("narrative", 20);

    // ── ETAPA 3: GUION COMPLETO (ajustado a duración real) ──
    progress("script", 22);
    const fullScript = await generateFullLengthScript({
      researchData,
      narrativeData,
      totalSeconds,
      language,
      narrativeStyle,
    });
    fs.writeFileSync(path.join(workDir, "script.txt"), fullScript.text);
    progress("script", 35, { wordCount: fullScript.text.split(/\s+/).length });

    // ── ETAPA 4: ESCENAS (división temporal real del guion) ─
    progress("scenes", 37);
    const scenes = divideScriptIntoScenes(fullScript.text, totalSeconds);
    fs.writeFileSync(path.join(workDir, "scenes.json"), JSON.stringify(scenes, null, 2));
    progress("scenes", 42, { sceneCount: scenes.length });

    // ── ETAPA 5: VOZ (local, narración completa) ───────────
    progress("voiceover", 45);
    const narrationPath = path.join(workDir, "narration.wav");
    await generateNarration({
      scriptText: fullScript.text,
      outputPath: narrationPath,
      language,
    });
    const actualNarrationDuration = await getAudioDurationSeconds(narrationPath);
    progress("voiceover", 55, { durationSeconds: actualNarrationDuration });

    // ── ETAPA 6: MÚSICA (local, ajustada a duración real) ──
    progress("music", 57);
    const musicPath = path.join(workDir, "music.wav");
    await generateBackgroundMusic({
      durationSeconds: actualNarrationDuration,
      mood: mapStyleToMood(narrativeStyle),
      outputPath: musicPath,
    });
    progress("music", 63);

    // ── ETAPA 7: VISUALES (MuAPI, una imagen/clip POR ESCENA) ─
    progress("visuals", 65);
    const visualModel = selectBestModel({ capability: "image-generation", studio: "documentary" });
    const sceneVisuals = [];
    for (let i = 0; i < scenes.length; i++) {
      const scene = scenes[i];
      const visual = await callMuapi({
        modelId: visualModel,
        input: {
          prompt: buildVisualPrompt(scene, visualStyle),
          referenceFiles: referenceFiles.filter((f) => f.type === "image"),
        },
      });
      sceneVisuals.push({ sceneIndex: i, ...visual });
      progress("visuals", 65 + Math.round((i / scenes.length) * 15), {
        completedScenes: i + 1,
        totalScenes: scenes.length,
      });
    }
    fs.writeFileSync(path.join(workDir, "visuals.json"), JSON.stringify(sceneVisuals, null, 2));
    progress("visuals", 80);

    // ── ETAPA 8: SUBTÍTULOS (timestamps reales del audio) ──
    progress("subtitles", 82);
    const srtPath = path.join(workDir, "subtitles.srt");
    const srtContent = generateSrtFromScript(fullScript.text, actualNarrationDuration);
    fs.writeFileSync(srtPath, srtContent);
    progress("subtitles", 85);

    // ── ETAPA 9: MONTAJE (FFmpeg real, resolución/formato reales) ─
    progress("assembly", 87);
    const finalVideoPath = path.join(workDir, "final.mp4");
    await assembleVideo({
      sceneVisuals,
      scenes,
      narrationPath,
      musicPath,
      srtPath,
      width,
      height,
      totalDurationSeconds: actualNarrationDuration,
      outputPath: finalVideoPath,
    });
    progress("assembly", 95);

    // ── ETAPA 10: EXPORTACIÓN ───────────────────────────────
    progress("export", 97);
    const manifest = {
      jobId,
      topic,
      durationSeconds: actualNarrationDuration,
      resolution: `${width}x${height}`,
      files: {
        video: `/uploads/documentary/${jobId}/final.mp4`,
        script: `/uploads/documentary/${jobId}/script.txt`,
        subtitles: `/uploads/documentary/${jobId}/subtitles.srt`,
        research: `/uploads/documentary/${jobId}/research.json`,
      },
    };
    fs.writeFileSync(path.join(workDir, "manifest.json"), JSON.stringify(manifest, null, 2));
    progress("export", 100, { ok: true, result: manifest });

    return { ok: true, result: manifest };
  } catch (err) {
    console.error(`[Documentary:${jobId}] FALLO en pipeline:`, err);
    updateJobProgress(jobId, "error", null, { error: err.message });
    throw err;
  }
}

/* ================================================================
 * FUNCIONES AUXILIARES
 * ================================================================ */

function buildResearchPrompt(topic, description, language) {
  return `Investiga en profundidad el siguiente tema para un documental. ` +
    `Necesito datos verificables, hechos documentados, fechas, nombres, fuentes ` +
    `y contexto histórico relevante. No inventes datos; si algo es incierto, indícalo.\n\n` +
    `Tema: ${topic}\nDescripción adicional: ${description || "(ninguna)"}\nIdioma: ${language}`;
}

function buildNarrativePrompt(researchData, style, totalSeconds, language) {
  const minutes = Math.round(totalSeconds / 60);
  return `A partir de esta investigación, construye la estructura narrativa de un ` +
    `documental de ${minutes} minutos en estilo "${style}". Define actos, puntos de ` +
    `giro, ganchos de retención cada 60-90 segundos, y el arco emocional completo.\n\n` +
    `Investigación:\n${JSON.stringify(researchData)}\n\nIdioma: ${language}`;
}

/**
 * Genera el guion completo iterando por bloques hasta cubrir la duración
 * real solicitada. Esto es lo que evita el bug actual de "guion breve
 * que no llega a 30/40/60 minutos": en vez de pedir el guion entero de
 * una sola pasada (que los modelos suelen truncar), se pide bloque a
 * bloque hasta acumular el conteo de palabras objetivo.
 *
 * Regla de estimación: ~130-150 palabras de narración por minuto hablado.
 */
async function generateFullLengthScript({ researchData, narrativeData, totalSeconds, language, narrativeStyle }) {
  const wordsPerMinute = 140;
  const targetWordCount = Math.round((totalSeconds / 60) * wordsPerMinute);

  const scriptModel = selectBestModel({ capability: "long-form-text", studio: "documentary" });

  let fullText = "";
  let currentWordCount = 0;
  let blockIndex = 0;
  const maxBlocks = 30; // salvaguarda contra bucles infinitos

  while (currentWordCount < targetWordCount && blockIndex < maxBlocks) {
    const block = await callMuapi({
      modelId: scriptModel,
      input: {
        prompt: buildScriptBlockPrompt({
          researchData,
          narrativeData,
          narrativeStyle,
          language,
          previousText: fullText,
          blockIndex,
          targetWordCount,
          currentWordCount,
        }),
      },
    });

    const blockText = typeof block === "string" ? block : block.text || "";
    if (!blockText.trim()) break; // el modelo no tiene más que añadir

    fullText += (fullText ? "\n\n" : "") + blockText.trim();
    currentWordCount = fullText.split(/\s+/).filter(Boolean).length;
    blockIndex++;
  }

  return { text: fullText, wordCount: currentWordCount };
}

function buildScriptBlockPrompt({ researchData, narrativeData, narrativeStyle, language, previousText, blockIndex, targetWordCount, currentWordCount }) {
  const remaining = targetWordCount - currentWordCount;
  return `Continúa el guion de narración del documental (estilo: ${narrativeStyle}, idioma: ${language}). ` +
    `Esto es el bloque #${blockIndex + 1}. Faltan aproximadamente ${remaining} palabras para completar ` +
    `el guion completo de ${targetWordCount} palabras. Escribe SOLO texto narrado continuo, sin ` +
    `encabezados, sin notas de producción, sin corchetes. Mantén coherencia con lo ya escrito.\n\n` +
    `Estructura narrativa de referencia:\n${JSON.stringify(narrativeData)}\n\n` +
    `Investigación de referencia:\n${JSON.stringify(researchData)}\n\n` +
    (previousText ? `Texto ya escrito (últimas 400 palabras para mantener coherencia):\n${previousText.split(/\s+/).slice(-400).join(" ")}` : "Este es el inicio del guion.");
}

/**
 * Divide el guion en escenas con marcas de tiempo aproximadas,
 * basándose en duración total real, no en un número fijo arbitrario.
 * Regla: una escena nueva cada ~20-30 segundos de narración estimada.
 */
function divideScriptIntoScenes(scriptText, totalSeconds) {
  const sentences = scriptText.split(/(?<=[.!?])\s+/).filter(Boolean);
  const wordsPerSecond = 140 / 60;
  const secondsPerScene = 25;
  const wordsPerScene = Math.round(secondsPerScene * wordsPerSecond);

  const scenes = [];
  let buffer = [];
  let wordCount = 0;
  let elapsedSeconds = 0;

  for (const sentence of sentences) {
    buffer.push(sentence);
    wordCount += sentence.split(/\s+/).length;

    if (wordCount >= wordsPerScene) {
      const sceneDuration = wordCount / wordsPerSecond;
      scenes.push({
        text: buffer.join(" "),
        startSeconds: elapsedSeconds,
        durationSeconds: sceneDuration,
      });
      elapsedSeconds += sceneDuration;
      buffer = [];
      wordCount = 0;
    }
  }

  if (buffer.length > 0) {
    const sceneDuration = wordCount / wordsPerSecond;
    scenes.push({
      text: buffer.join(" "),
      startSeconds: elapsedSeconds,
      durationSeconds: sceneDuration,
    });
  }

  return scenes;
}

function buildVisualPrompt(scene, visualStyle) {
  return `${visualStyle}, cinematic documentary still, high detail, no text overlay. ` +
    `Escena: ${scene.text.slice(0, 300)}`;
}

function mapStyleToMood(narrativeStyle) {
  const map = {
    investigative: "investigative",
    mystery: "tense-mystery",
    dramatic: "dramatic",
  };
  return map[narrativeStyle] || "documentary-neutral";
}

function summarize(obj) {
  const str = typeof obj === "string" ? obj : JSON.stringify(obj);
  return str.slice(0, 300);
}

/**
 * Genera un SRT con timestamps reales repartidos sobre la duración
 * real del audio de narración (no estimados sobre texto corto).
 */
function generateSrtFromScript(scriptText, totalDurationSeconds) {
  const sentences = scriptText.split(/(?<=[.!?])\s+/).filter(Boolean);
  const totalWords = scriptText.split(/\s+/).filter(Boolean).length;
  const secondsPerWord = totalDurationSeconds / totalWords;

  let srt = "";
  let index = 1;
  let elapsed = 0;

  for (const sentence of sentences) {
    const wordCount = sentence.split(/\s+/).filter(Boolean).length;
    const duration = wordCount * secondsPerWord;
    const start = elapsed;
    const end = elapsed + duration;

    srt += `${index}\n${formatSrtTime(start)} --> ${formatSrtTime(end)}\n${sentence}\n\n`;
    elapsed += duration;
    index++;
  }

  return srt;
}

function formatSrtTime(seconds) {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  const ms = Math.floor((seconds % 1) * 1000);
  const pad = (n, len = 2) => String(n).padStart(len, "0");
  return `${pad(h)}:${pad(m)}:${pad(s)},${pad(ms, 3)}`;
}

/**
 * Obtiene la duración real del audio generado vía ffprobe.
 * Esto es lo que permite que TODO lo demás (escenas, subtítulos,
 * música, montaje) se ajuste a la duración REAL en vez de la estimada.
 */
function getAudioDurationSeconds(audioPath) {
  return new Promise((resolve, reject) => {
    execFile(
      "ffprobe",
      ["-v", "error", "-show_entries", "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", audioPath],
      (err, stdout) => {
        if (err) return reject(new Error(`ffprobe falló en ${audioPath}: ${err.message}`));
        resolve(parseFloat(stdout.trim()));
      }
    );
  });
}

/**
 * Monta el video final con FFmpeg real:
 * - Usa la resolución/formato REALES seleccionados en el panel (no 1080x1920 fijo).
 * - Usa NVENC (GPU RTX 4070 Ti) en vez de libx264 software para que sea rápido.
 * - Crea un slideshow de las imágenes de escena sincronizado con sus duraciones reales,
 *   en vez de un único fondo de color estático.
 * - Mezcla narración + música de fondo a niveles correctos (música más baja).
 * - Quema los subtítulos SRT reales.
 */
async function assembleVideo({ sceneVisuals, scenes, narrationPath, musicPath, srtPath, width, height, totalDurationSeconds, outputPath }) {
  const workDir = path.dirname(outputPath);
  const concatListPath = path.join(workDir, "concat_list.txt");

  // Construye lista de concat de FFmpeg: cada imagen de escena dura lo
  // que dura su escena real en segundos.
  let concatContent = "";
  for (let i = 0; i < sceneVisuals.length; i++) {
    const visual = sceneVisuals[i];
    const scene = scenes[i];
    const imagePath = visual.localPath || visual.url; // ajusta según lo que devuelva tu MuAPI
    concatContent += `file '${imagePath}'\nduration ${scene.durationSeconds.toFixed(2)}\n`;
  }
  // FFmpeg concat demuxer requiere repetir el último archivo sin duration al final
  if (sceneVisuals.length > 0) {
    const lastVisual = sceneVisuals[sceneVisuals.length - 1];
    const lastPath = lastVisual.localPath || lastVisual.url;
    concatContent += `file '${lastPath}'\n`;
  }
  fs.writeFileSync(concatListPath, concatContent);

  const args = [
    "-y",
    "-f", "concat",
    "-safe", "0",
    "-i", concatListPath,
    "-i", narrationPath,
    "-i", musicPath,
    "-filter_complex",
    `[1:a]volume=1.0[narr];[2:a]volume=0.18[music];[narr][music]amix=inputs=2:duration=first[aout];` +
    `[0:v]scale=${width}:${height}:force_original_aspect_ratio=decrease,pad=${width}:${height}:(ow-iw)/2:(oh-ih)/2,subtitles='${srtPath.replace(/\\/g, "/")}'[vout]`,
    "-map", "[vout]",
    "-map", "[aout]",
    "-c:v", "h264_nvenc", // GPU NVENC (RTX 4070 Ti) — fallback a libx264 si no disponible
    "-preset", "fast",
    "-c:a", "aac",
    "-b:a", "192k",
    "-t", String(totalDurationSeconds),
    outputPath,
  ];

  return new Promise((resolve, reject) => {
    execFile("ffmpeg", args, { maxBuffer: 1024 * 1024 * 50 }, (err, stdout, stderr) => {
      if (err) {
        console.warn("[assembleVideo] NVENC falló, reintentando con libx264 software:", err.message);
        const fallbackArgs = args.map((a) => (a === "h264_nvenc" ? "libx264" : a));
        execFile("ffmpeg", fallbackArgs, { maxBuffer: 1024 * 1024 * 50 }, (err2, stdout2, stderr2) => {
          if (err2) return reject(new Error(`FFmpeg falló incluso con libx264: ${stderr2}`));
          resolve();
        });
        return;
      }
      resolve();
    });
  });
}

module.exports = {
  runDocumentaryPipeline,
};
