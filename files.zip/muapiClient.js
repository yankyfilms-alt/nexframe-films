/**
 * muapiClient.js
 * ============================================================
 * CAPA DE BAJO NIVEL — conecta con tu MuAPI real.
 *
 * ESTA ES LA ÚNICA PARTE QUE TIENES QUE ADAPTAR A TU server.js REAL.
 * El resto del pipeline (documentaryPipeline.js) NO debe tocarse:
 * llama a estas funciones y no le importa cómo hables con MuAPI por debajo.
 *
 * Si ya tienes un cliente MuAPI dentro de server.js (por ejemplo
 * `callMuapi()`, `muapiRequest()`, etc.), simplemente reemplaza el
 * cuerpo de las funciones de abajo para que llamen a tu función real
 * en vez de hacer fetch() directo aquí.
 * ============================================================
 */

const MUAPI_BASE_URL = process.env.MUAPI_BASE_URL || "https://api.muapi.ai"; // AJUSTA a tu base real
const MUAPI_KEY = process.env.MUAPI_KEY || process.env.MUAPI_API_KEY;

if (!MUAPI_KEY) {
  console.warn("[muapiClient] ⚠️  No se encontró MUAPI_KEY/MUAPI_API_KEY en variables de entorno.");
}

/**
 * Carga tu registro de modelos real. Ajusta la ruta si tu archivo
 * vive en otro sitio (src/data/muapiRegistry.js en tu plano original).
 */
let muapiRegistry = {};
try {
  muapiRegistry = require("../src/data/muapiRegistry.js");
} catch (e) {
  console.warn("[muapiClient] No se pudo cargar muapiRegistry.js automáticamente. " +
    "Ajusta la ruta de require() en muapiClient.js a la ubicación real del archivo.");
}

/**
 * ------------------------------------------------------------
 * AUTO-SELECCIÓN DE MODELO
 * ------------------------------------------------------------
 * El usuario pidió: "que el sistema elija la mejor [modelo] que vea
 * para cada proyecto" en lugar de seleccionar manualmente.
 *
 * Estrategia de selección, en este orden de prioridad:
 *   1. Si el usuario fijó un modelo explícito en el panel → se respeta.
 *   2. Si no, se filtra el registry por capability + studio compatible.
 *   3. Entre los candidatos, se ordena por un score de calidad/velocidad
 *      definido en el propio registry (campo `qualityScore` o similar).
 *   4. Si el registry no tiene score, se usa el primero compatible.
 *
 * AJUSTA los nombres de campo (`capability`, `studios`, `qualityScore`)
 * a como estén realmente definidos en tu muapiRegistry.js.
 * ------------------------------------------------------------
 */
function selectBestModel({ capability, studio, explicitModelId = null }) {
  if (explicitModelId) {
    return explicitModelId;
  }

  const candidates = Object.entries(muapiRegistry)
    .filter(([id, def]) => {
      const matchesCapability = def.capability === capability || (def.capabilities || []).includes(capability);
      const matchesStudio = !def.studios || def.studios.includes(studio);
      return matchesCapability && matchesStudio;
    })
    .map(([id, def]) => ({ id, ...def }));

  if (candidates.length === 0) {
    throw new Error(`[selectBestModel] No hay modelos compatibles con capability="${capability}" para studio="${studio}". Revisa muapiRegistry.js`);
  }

  candidates.sort((a, b) => (b.qualityScore || 0) - (a.qualityScore || 0));

  console.log(`[selectBestModel] capability=${capability} studio=${studio} → elegido: ${candidates[0].id} (de ${candidates.length} candidatos)`);
  return candidates[0].id;
}

/**
 * ------------------------------------------------------------
 * LLAMADA GENÉRICA A MUAPI
 * ------------------------------------------------------------
 * AJUSTA esta función al contrato real de tu MuAPI:
 * - ¿Es síncrono (devuelve el resultado directo) o asíncrono
 *   (devuelve un job_id que hay que pollear)?
 * - ¿El endpoint es /generate, /v1/jobs, /pipeline?
 *
 * Por defecto asumo un patrón async con polling, que es el más
 * común para research/texto/imagen/video pesados.
 * ------------------------------------------------------------
 */
async function callMuapi({ modelId, input, timeoutMs = 120000, pollIntervalMs = 3000 }) {
  if (!MUAPI_KEY) {
    throw new Error("MUAPI_KEY no configurada. Define MUAPI_KEY en tu .env");
  }

  // 1. Lanzar el job
  const createRes = await fetch(`${MUAPI_BASE_URL}/v1/generate`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${MUAPI_KEY}`,
    },
    body: JSON.stringify({ model: modelId, input }),
  });

  if (!createRes.ok) {
    const errText = await createRes.text().catch(() => "");
    throw new Error(`MuAPI rechazó la petición (${createRes.status}) modelo=${modelId}: ${errText}`);
  }

  const createData = await createRes.json();

  // Si tu MuAPI devuelve el resultado directo sin job_id, ajusta aquí:
  if (createData.result || createData.output) {
    return createData.result || createData.output;
  }

  const jobId = createData.job_id || createData.id;
  if (!jobId) {
    throw new Error(`MuAPI no devolvió job_id ni resultado directo para modelo=${modelId}. Respuesta: ${JSON.stringify(createData)}`);
  }

  // 2. Polling hasta que termine
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    const statusRes = await fetch(`${MUAPI_BASE_URL}/v1/jobs/${jobId}`, {
      headers: { Authorization: `Bearer ${MUAPI_KEY}` },
    });
    const statusData = await statusRes.json();

    if (statusData.status === "completed" || statusData.status === "done") {
      return statusData.result || statusData.output;
    }
    if (statusData.status === "failed" || statusData.status === "error") {
      throw new Error(`MuAPI job ${jobId} (modelo=${modelId}) falló: ${statusData.error || "sin detalle"}`);
    }
    await new Promise((r) => setTimeout(r, pollIntervalMs));
  }

  throw new Error(`MuAPI job ${jobId} (modelo=${modelId}) superó el timeout de ${timeoutMs}ms`);
}

module.exports = {
  selectBestModel,
  callMuapi,
  muapiRegistry,
};
