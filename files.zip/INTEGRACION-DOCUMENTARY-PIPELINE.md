# DOCUMENTARY STUDIO — INTEGRACIÓN DEL PIPELINE REAL

## Qué cambia exactamente

**Antes (lo que tienes ahora):**
```
Tema escrito → texto local genérico → TTS local → FFmpeg con fondo de color fijo 1080x1920
```

**Después (con estos 3 archivos):**
```
Tema → Research real (MuAPI) → Narrativa (MuAPI) → Guion completo a duración real (MuAPI,
por bloques) → División en escenas reales → Voz local (duración real medida con ffprobe) →
Música local ajustada a esa duración → Visuales reales por escena (MuAPI) → Subtítulos con
timestamps reales → Montaje FFmpeg con NVENC en la resolución/formato REALES del panel →
MP4 final descargable de verdad
```

---

## 3 archivos que te he dado

| Archivo | Qué hace | Qué tienes que tocar |
|---|---|---|
| `muapiClient.js` | Habla con tu MuAPI real + auto-selecciona el mejor modelo por capability | Ajustar `MUAPI_BASE_URL`, el contrato de `callMuapi()` (síncrono vs polling), y los nombres de campo en `selectBestModel()` (`capability`, `studios`, `qualityScore`) para que coincidan con tu `muapiRegistry.js` real |
| `localMediaClient.js` | Voz (XTTS/Kokoro) y música (ACE-Step/YuE) locales | Ajustar `LOCAL_TTS_URL` y `LOCAL_MUSIC_URL` a los puertos reales donde corren esos servicios en GRANOSCAR, o cambiar a `runPythonScript()` si los invocas como script directo |
| `documentaryPipeline.js` | Orquesta las 10 etapas reales | No debería necesitar cambios salvo el formato de `visual.localPath`/`visual.url` que devuelva tu MuAPI en la etapa de visuales |

---

## Paso 1 — Copiar archivos

```powershell
# Desde la raíz de tu proyecto NEXFRAME FILMS
copy muapiClient.js .\server\lib\muapiClient.js
copy localMediaClient.js .\server\lib\localMediaClient.js
copy documentaryPipeline.js .\server\lib\documentaryPipeline.js
```

(Ajusta las rutas si tu estructura no tiene carpeta `server/lib/` — pueden ir junto a `server.js` directamente, solo ajusta los `require()` relativos dentro de los archivos.)

## Paso 2 — Variables de entorno (.env)

Añade lo que falte:

```
MUAPI_BASE_URL=https://tu-endpoint-real-de-muapi.com
MUAPI_KEY=tu_key_real_aqui
LOCAL_TTS_URL=http://localhost:8001
LOCAL_MUSIC_URL=http://localhost:8002
```

## Paso 3 — Conectar al endpoint existente en `server.js`

Busca dónde tienes definido `POST /api/muapi/pipeline` (o el endpoint específico que
usa Documentary Studio) y haz esto — **sin tocar el resto de studios que ya pasan por
ese mismo endpoint**:

```javascript
const { runDocumentaryPipeline } = require("./lib/documentaryPipeline");

app.post("/api/muapi/pipeline", async (req, res) => {
  const { studio, ...config } = req.body;

  if (studio === "documentary") {
    // 1. Crea el job con TU función existente de jobs (la que ya usas
    //    para los otros studios) — esto mantiene compatibilidad con
    //    el resto del sistema de tracking de jobs.
    const jobId = createJobRecord({ studio: "documentary", config });

    // 2. Responde INMEDIATAMENTE — el frontend ya hace polling a /api/task/:id
    res.json({ ok: true, job_id: jobId, status: "queued" });

    // 3. Procesa en background. updateJobProgress es TU función existente
    //    que actualiza el job — si no la tienes genérica así, dime cómo
    //    está hecha tu sistema de progreso de jobs y te adapto la firma.
    runDocumentaryPipeline(config, jobId, updateJobProgress).catch((err) => {
      console.error(`Pipeline documental ${jobId} falló:`, err);
      markJobFailed(jobId, err.message); // tu función existente
    });

    return; // importante: no caer al resto del handler
  }

  // ... aquí sigue tu lógica existente para musicvideo, marketing, etc.
});
```

**Si no tienes `createJobRecord`, `updateJobProgress` o `markJobFailed` como
funciones genéricas reutilizables**, dime cómo gestiona `server.js` el estado
de los jobs actualmente (¿un objeto en memoria? ¿una tabla en SQLite/Supabase?)
y te doy esas 3 funciones también, adaptadas a tu mecanismo real.

## Paso 4 — Arreglar "Exportar MP4" (ahora descarga JSON en vez del video)

Busca el handler del botón "Exportar MP4" en el frontend. Probablemente apunta a
descargar el objeto de resultado completo como JSON. Cámbialo para que apunte
directo al archivo real generado:

```javascript
// src/App.jsx — botón "Exportar MP4"
function handleExportMp4(job) {
  const videoUrl = job.result.files.video; // viene del manifest.json real
  const a = document.createElement("a");
  a.href = videoUrl;
  a.download = `documental-${job.topic}.mp4`;
  a.click();
}
```

## Paso 5 — Las "Acciones rápidas" sueltas (Investigación, Guion, etc.)

Mencionas que botones individuales como "Investigación" o "Guion" generan JSON
local predefinido. Si quieres que también funcionen de forma independiente
(sin correr el pipeline completo), expón cada etapa del módulo como su propio
mini-endpoint:

```javascript
app.post("/api/documentary/research", async (req, res) => {
  const { topic, description, language } = req.body;
  try {
    const model = selectBestModel({ capability: "research", studio: "documentary" });
    const result = await callMuapi({ modelId: model, input: { prompt: buildResearchPrompt(topic, description, language) } });
    res.json({ ok: true, result });
  } catch (err) {
    res.status(500).json({ ok: false, error: { message: err.message } });
  }
});
```

(Repite el patrón para `/api/documentary/script`, `/api/documentary/voiceover`, etc.,
reutilizando las funciones internas de `documentaryPipeline.js` — puedo exportarlas
todas si quieres que cada acción rápida sea 100% real también, dime y te las separo.)

---

## Qué resuelve esto exactamente, punto por punto de tu lista de limitaciones

| Limitación que reportaste | Cómo queda resuelta |
|---|---|
| No realiza investigación real | Etapa 1 llama a MuAPI con prompt de investigación verificable |
| No genera guion completo de la duración seleccionada | `generateFullLengthScript()` itera por bloques hasta alcanzar el conteo de palabras real objetivo (≈140 palabras/min) |
| No llama a los modelos elegidos | `selectBestModel()` + `callMuapi()` en cada etapa, con auto-selección como pediste |
| No genera visuales por escena | Etapa 7 genera una imagen por cada escena real del guion dividido |
| No monta música/efectos | Etapa 6, música local ajustada a la duración real del audio medido |
| Ignora resolución/formato seleccionados | `RESOLUTION_MAP` lee `resolutionKey` del panel y FFmpeg usa esas dimensiones reales |
| Duración depende del tema breve, no de 30/40/60 min | Todo el pipeline parte de `DURATION_MAP_SECONDS` y se valida con ffprobe en audio real |
| Archivos de referencia no se usan | `referenceFiles` se pasa a research y a visuales (filtrado por tipo) |
| "Exportar MP4" descarga JSON | Paso 4 de esta guía |

---

## Siguiente paso real

Esto está listo para conectar, pero **2 cosas dependen 100% de tu código real** y
no puedo adivinarlas bien:

1. El contrato exacto de tu MuAPI (¿síncrono o con job_id + polling? ¿qué campos
   devuelve?) — ajusta `callMuapi()` en `muapiClient.js`.
2. Cómo tienes montado el sistema de jobs en `server.js` (`createJobRecord`,
   `updateJobProgress`, `markJobFailed`).

Cuando subas tu `server.js` y `muapiRegistry.js` reales, te ajusto estas dos piezas
exactas en cuestión de minutos — el resto del pipeline (las 10 etapas, duración real,
FFmpeg con NVENC, auto-selección de modelo) ya queda funcionando tal cual.
