/**
 * localMediaClient.js
 * ============================================================
 * CAPA LOCAL — voz y música generadas en GRANOSCAR (sin coste por
 * generación, sin depender de MuAPI para estas dos etapas).
 *
 * Asume que tienes corriendo localmente (según tu infraestructura
 * documentada): XTTS-v2/Kokoro para voz y ACE-Step/YuE para música,
 * cada uno expuesto como un servicio HTTP local (puerto propio) o
 * invocable como proceso Python.
 *
 * AJUSTA las URLs/puertos a como los tengas montados realmente.
 * Si los invocas como script Python en vez de servicio HTTP, sustituye
 * el cuerpo de cada función por un spawn de proceso (ver función
 * `runPythonScript` al final como alternativa).
 * ============================================================
 */

const path = require("path");
const fs = require("fs");
const { spawn } = require("child_process");

const TTS_SERVICE_URL = process.env.LOCAL_TTS_URL || "http://localhost:8001"; // AJUSTA puerto real de XTTS/Kokoro
const MUSIC_SERVICE_URL = process.env.LOCAL_MUSIC_URL || "http://localhost:8002"; // AJUSTA puerto real de ACE-Step/YuE

/**
 * ------------------------------------------------------------
 * VOZ — narración del documental
 * ------------------------------------------------------------
 * Genera un MP3/WAV de la narración completa a partir del guion.
 * Para documentales largos (30-60 min), esto puede tardar varios
 * minutos en CPU/GPU local — está pensado para ejecutarse async,
 * no bloquear la respuesta HTTP del panel.
 * ------------------------------------------------------------
 */
async function generateNarration({ scriptText, voiceId = "default", outputPath, language = "es" }) {
  try {
    const res = await fetch(`${TTS_SERVICE_URL}/tts`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        text: scriptText,
        voice: voiceId,
        language,
      }),
    });

    if (!res.ok) {
      throw new Error(`Servicio TTS local respondió ${res.status}`);
    }

    const audioBuffer = Buffer.from(await res.arrayBuffer());
    fs.writeFileSync(outputPath, audioBuffer);

    return { ok: true, path: outputPath };
  } catch (err) {
    console.error("[generateNarration] Error:", err.message);
    throw new Error(
      `No se pudo generar la narración local. Verifica que el servicio TTS esté corriendo en ${TTS_SERVICE_URL}. Detalle: ${err.message}`
    );
  }
}

/**
 * ------------------------------------------------------------
 * MÚSICA — banda sonora de fondo
 * ------------------------------------------------------------
 * Genera música instrumental de fondo ajustada a la duración real
 * del documental y al tono narrativo (tenso, misterioso, dramático,
 * neutro/informativo) según el estilo elegido en el panel.
 * ------------------------------------------------------------
 */
async function generateBackgroundMusic({ durationSeconds, mood = "documentary-neutral", outputPath }) {
  try {
    const res = await fetch(`${MUSIC_SERVICE_URL}/generate`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        duration: durationSeconds,
        prompt: mapMoodToPrompt(mood),
      }),
    });

    if (!res.ok) {
      throw new Error(`Servicio de música local respondió ${res.status}`);
    }

    const audioBuffer = Buffer.from(await res.arrayBuffer());
    fs.writeFileSync(outputPath, audioBuffer);

    return { ok: true, path: outputPath };
  } catch (err) {
    console.error("[generateBackgroundMusic] Error:", err.message);
    throw new Error(
      `No se pudo generar música local. Verifica que el servicio esté corriendo en ${MUSIC_SERVICE_URL}. Detalle: ${err.message}`
    );
  }
}

function mapMoodToPrompt(mood) {
  const moods = {
    "documentary-neutral": "ambient documentary background score, subtle strings, slow tempo, neutral tone",
    "tense-mystery": "dark ambient tension, low drones, sparse piano, mystery documentary score",
    "dramatic": "cinematic orchestral, building tension, emotional strings, dramatic documentary score",
    "investigative": "minimal suspenseful electronic pulse, investigative true-crime documentary score",
  };
  return moods[mood] || moods["documentary-neutral"];
}

/**
 * ------------------------------------------------------------
 * ALTERNATIVA: si tus modelos locales se invocan como script
 * Python directo (no como servicio HTTP), usa esta función en
 * vez de fetch(). Descomenta y ajusta rutas según tu stack real
 * (ej. C:\GRANOSCAR_AI\xtts\generate.py).
 * ------------------------------------------------------------
 */
function runPythonScript(scriptPath, args = []) {
  return new Promise((resolve, reject) => {
    const proc = spawn("python", [scriptPath, ...args]);
    let stdout = "";
    let stderr = "";

    proc.stdout.on("data", (d) => (stdout += d.toString()));
    proc.stderr.on("data", (d) => (stderr += d.toString()));

    proc.on("close", (code) => {
      if (code === 0) {
        resolve(stdout);
      } else {
        reject(new Error(`Script ${scriptPath} terminó con código ${code}: ${stderr}`));
      }
    });
  });
}

module.exports = {
  generateNarration,
  generateBackgroundMusic,
  runPythonScript,
};
